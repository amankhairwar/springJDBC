package com.spring.jdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.spring.jdbc.entities.Student;

public class StudentDaoImpl implements StudentDao{
	
	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	private JdbcTemplate template;
	@Override
	public int insert(Student student) {
		String query="insert into Student(id,name,city) values(?,?,?)";
		int res=this.template.update(query,student.getId(),student.getName(),student.getCity());
		return res;
	}
	@Override
	public int change(Student student) {
		//update the record 
		String query="update Student set name=?, city=? where id=?";
		int res =this.template.update(query,student.getName(),student.getCity(),student.getId());
		return res;
	}
	@Override
	public int deleted(Student student) {
		String query ="delete from Student where id=?";
		int res=this.template.update(query,student.getId());
		return res;
	}
	@Override
	public Student getStudent(int id) {
		String query="select * from Student where id =?";
		RowMapper<Student> rowMapper = new RowMapperImpl();
		Student s =this.template.queryForObject(query, rowMapper, id);
		return s;
	}
	

}
