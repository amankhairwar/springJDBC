package com.spring.jdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.dao.StudentDao;
import com.spring.jdbc.dao.StudentDaoImpl;
import com.spring.jdbc.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.out.println("my program started");
//    	JdbcTemplate 
    	ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/jdbc/config.xml");
//    	JdbcTemplate temp =context.getBean("jdbcTemplate",JdbcTemplate.class);
//    	//insert query 
//    	String query="insert into Student(id,name,city) values(?,?,?)";
//    	int rowsUpdated=temp.update(query,3,"Manish","Kanpur");
    	StudentDao dao = context.getBean("studentDao",StudentDao.class);
//    	Student s= new Student();
//    	s.setId(12);
//    	s.setName("Naman");
//    	s.setCity("Varanasi");
//    	int res=dao.insert(s);
////    	System.out.println("student added "+res);
//    	Student s = new Student();
//    	s.setId(2);
//    	s.setName("Prakash");
//    	s.setCity("Madras");
//    	int res=dao.change(s);
//    	System.out.println("data changed "+res);
//    	Student s2= new Student();
//    	s2.setId(12);
//    	int result=dao.deleted(s2);
//    	System.out.println(result+" record deleted whose name is "+s2.getName());
//    	
    	Student s=dao.getStudent(1);
    	System.out.println("City: "+s.getCity()+"\nName: "+s.getName()+"\nID: "+s.getId());
    	
    	
    }
}
